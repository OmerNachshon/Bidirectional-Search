#pragma once
class Cell
{
private:
	int row;
	int col;
public:
	Cell();
	Cell(int r, int c);
	~Cell();
	int getRow() { return row; }
	int getCol() { return col; }
};


#include "Cell.h"



Cell::Cell()
{
}

Cell::Cell(int r, int c)
{
	row = r;
	col = c;
}


Cell::~Cell()
{
}
